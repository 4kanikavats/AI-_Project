import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia #pip install wikipedia
import webbrowser
import os
import smtplib

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voice', voices[0].id)


def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=5 and hour<12:
        print("Good Morning!")
        speak("Good Morning!")

    elif hour>=12 and hour<18:
        print("Good Afternoon!")
        speak("Good Afternoon!")   

    elif hour>=18 and hour<22:
        print("Good Evening!")
        speak("Good Evening!")
    
    else:
        print("Good Night!")
        speak("Good Night!")

    print("I am Mohan. Your virtual assistant. Please tell me how may I help you")       
    speak("I am Mohan. Your virtual assistant. Please tell me how may I help you")       

def takeCommand():
    #It takes microphone input from the user and returns string output

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        speak("I am listening.")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        speak("wait...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")
        speak(f"User said: {query}\n")
        speak("wait...")

    except Exception as e:
        # print(e)    
        print("Say that again please...")
        speak("Sorry! not able to understand. Say that again please...")  
        return "None"
    return query

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('mohitsheoran.21@gmail.com', 'Usha@174')
    server.sendmail('mohitsheoran.21@gmail.com', to, content)
    server.close()

if __name__ == "__main__":
    wishMe()
    while True:
    # if 1:
        query = takeCommand().lower()

        # Logic for executing tasks based on query
        if 'wikipedia' in query:
            try:
                speak('Searching Wikipedia...')
                query = query.replace("wikipedia", "")
                results = wikipedia.summary(query, sentences=2)
                speak("According to Wikipedia")
                print(results)
                speak(results)

            except Exception as e:
                speak("Sorry! due to some issue unable to search in wikipedia")                            

        elif 'open youtube' in query:
            try:                
                webbrowser.open("youtube.com")
                speak("Done! youtube Open.")
            
            except Exception as e:
                speak("Sorry! due to some issue unable to open Youtube.")

        elif 'open google' in query:
            try:
                webbrowser.open("google.com")
                speak("Done! google Open.")

            except Exception as e:
                speak("Sorry! due to some issue unable to open google.")

        elif 'open stackoverflow' in query:
            try:
                webbrowser.open("stackoverflow.com")
                speak("Done! stackoverflow open.")

            except Exception as e:
                speak("Sorry! due to some issue unable to open stackoverflow")


        elif 'play music' in query:
            try:
                music_dir = 'D:\\Non Critical\\songs\\Favorite Songs2'
                songs = os.listdir(music_dir)
                print(songs)    
                os.startfile(os.path.join(music_dir, songs[0]))
                speak("Done! play Music.")

            except Exception as e:
                speak("Sorry! due to some issue unable to open play music.")

        elif 'time' in query:
            try:
                strTime = datetime.datetime.now().strftime("%H:%M:%S")    
                speak(f"Sir, the time is {strTime}")

            except Exception as e:
                speak("Sorry! due to some issue unable to tell time.")

        elif 'open code' in query:
            try:
                codePath = "C:\\Users\\mohit\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
                os.startfile(codePath)
                speak("Done! Code open.")

            except Exception as e:
                speck("Sorry! Due to some issue code not open.")

        elif 'email' in query:
            try:
                speak("What should I say?")
                content = takeCommand()
                to = "4kanikavats@gmail.com"    
                sendEmail(to, content)
                speak("Email has been sent!")
            except Exception as e:
                print(e)
                speak("Sorry my friend. I am not able to send this email")
                
        elif 'exit' in query:
            quit()
